package com.example.locale_lite;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Pending extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pending_image);
    }
}
